#include <stdio.h>
int main() {
   int v;
   int j;
   int somme;

scanf ("%d", &v);
printf ("v : %d\n",v);
scanf ("%d", &j);
printf ("j : %d\n",j);
somme = j + v;
printf ("somme : %d\n",somme);

 return 0;
}